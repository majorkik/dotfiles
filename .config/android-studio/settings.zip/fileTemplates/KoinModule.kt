#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import org.koin.dsl.module

val ${NAME} = module {
    // Your dependencies
}