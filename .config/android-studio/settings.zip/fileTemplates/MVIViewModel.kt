#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import androidx.lifecycle.ViewModel
import org.orbitmvi.orbit.ContainerHost
import org.orbitmvi.orbit.viewmodel.container

internal class ${NAME}ViewModel: ViewModel(), ContainerHost<${NAME}ViewState, ${NAME}SideEffect> {

    override val container = container<${NAME}ViewState, ${NAME}SideEffect>(${NAME}ViewState())
}

internal class ${NAME}ViewState

internal sealed class ${NAME}SideEffect
